<HTML>
<HEAD>
<TITLE>Responsive Web Design (RWD)</TITLE>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="style.css" rel="stylesheet" type="text/css" />
</HEAD>
<BODY>
<div id="page-content">
<?php
include_once("header.php");
?>
<?php
include("content.php");
?>
<?php
include("footer.php");
?>
</div>
</BODY>
</HTML>