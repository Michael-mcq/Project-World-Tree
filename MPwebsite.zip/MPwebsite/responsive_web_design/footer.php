<div id="footer">
<a href="#">About</a>
<a href="#">Contact</a>
<a href="#">Terms</a>
</div>