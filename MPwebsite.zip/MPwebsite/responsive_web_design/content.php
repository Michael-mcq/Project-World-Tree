<div id="main-content">
<h2>Login Page with Responsive Web Design</h2>
<p>This login page is created as an example of Responsive Web Design (RWD) for adapting to various screen resolutions. CSS3 Media Queries are used to achieve responsive web design. We can make quick experiments on this responsive design by adjusting the brower size.</p>
<p><img src="responsive_shapes.jpg" /></p>

</div>
<div id="sidebar">
<?php
include("login.php");
?>
</div>