<div id="login-panel">
<input type="text" name="loginname" placeholder="Login Name" />
<input type="password" name="password" placeholder="Password" />
<input type="submit" name="login" value="Login" />
</div>
