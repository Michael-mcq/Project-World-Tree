
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, maximum-scale=1">

	<title>Homepage</title>
	<link rel="icon" href="testicon.png" type="image/png">
	<link rel="shortcut icon" href="testicon.ico" type="img/x-icon">


	<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="css/style.css" rel="stylesheet" type="text/css">

	<link href="css/responsive.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" type="text/css">

	<script type="text/javascript" src="js/jquery.1.8.3.min.js"></script>
	<script type="text/javascript" src="js/jquery-scrolltofixed.js"></script>
	<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
	<script type="text/javascript" src="js/jquery.isotope.js"></script>

</head>

<body>

	<nav class="main-nav-outer" id="test">
		<!--main-nav-start-->
		<div class="container">
      <div class="small-logo-mobile"><a href=""><img src="img/testicon.png" alt=""></a></div>
			<ul class="main-nav">
				<li><a href="../../home.php">Home</a></li>
				<li class="small-logo"><a href=""><img src="img/testicon.png" alt=""></a></li>
                <li><a href="../../loginregister/">Login</a></li>
			</ul>
			<a class="res-nav_click" href="#"><i class="fa fa-bars"></i></a>
		</div>
	</nav>
    

	<section class="main-section client-part" id="service">
		<!--main-section-start-->
<?php
	ini_set('display_errors', 1); //This is handy for debugging PHP errors.
    error_reporting(E_ALL);
	include('config.php');
	include('db.php');

	
	

	if (isset($_POST['done'])){

		db_update('choose_settings', array(
			'title'		=> AddSlashes($_POST['title']),
			'root_url'	=> AddSlashes($_POST['root_url']),
			'copyright_text'	=> AddSlashes($_POST['copyright_text']),
                        'copyright_year'         => AddSlashes($_POST['copyright_year']),
                        'copyright_url'         => AddSlashes($_POST['copyright_url']),
                        'main_page_text'         => AddSlashes($_POST['main_page_text']),
                        'warn_box_blurb'         => AddSlashes($_POST['warn_box_blurb']),
                        'new_room_blurb'         => AddSlashes($_POST['new_room_blurb']),
                        'kill_depth'         => AddSlashes($_POST['kill_depth']),
                      
		), "id=1");

		header("location: admin.php?done=1");
		exit;
	}


	#
	# get info for display
	#

	include('header.txt');
?>


<h1>Site Admin</h1>

<div class="godbox">
	<a href="p_routes.php">Story Routes</a> | <a href="p_authors.php">Authors</a> | <a href="purge.php">Purge Problem Rooms</a>
</div>

<?php if (isset($_GET['done'])){ ?>
	<div style="border: 1px solid #000000; padding: 10px; background-color: #eeeeee;">Your changes have been saved.</div>
<?php } ?>


<form action="admin.php" method="post">
<input type="hidden" name="done" value="1" />
	<p>Site Title:<br /><input name="title" type="text" size="50" value="<?= HtmlSpecialChars($settings['title']) ?>"/></p><br />
	<p>Root URL:<br /><input name="root_url" type="text" size="50" value="<?= $settings['root_url'] ?>"/></p><br />
	<p>Copyright Name:<br /><input name="copyright_text" type="text" size="50" value="<?= HtmlSpecialChars($settings['copyright_text']) ?>"/><br />
	<small>This is the <em>Your Name</em> in <strong>&copy; 2020 Your Name</strong> at the bottom of each page.</small></p><br />
	<p>Copyright Year:<br /><input name="copyright_year" type="text" size="50" value="<?= $settings['copyright_year'] ?>"/></p><br />
	<p>Copyright URL:<br /><input name="copyright_url" type="text" size="50" value="<?= $settings['copyright_url'] ?>"/><br />
	<small>This is the URL for the link in the copyright at the bottom of each page.</small></p><br />
	<p>Main Page Text:<br /><textarea name="main_page_text" cols="50" rows="10"><?= $settings['main_page_text'] ?></textarea></p><br />
	<p>Content Warning Text:<br /><textarea name="warn_box_blurb" cols="50" rows="10"><?= $settings['warn_box_blurb'] ?></textarea><br />
	<small>This is the content warning that will display when the user opens the first "room".</small></p><br />
	<p>New Room Text:<br /><textarea name="new_room_blurb" cols="50" rows="10"><?= $settings['new_room_blurb'] ?></textarea><br />
	<small>This is the text at the top of a page when the user reaches the end of an unfinished branch and can add content.</small></p><br />
	<p>Depth Before End:<br /><input name="kill_depth" type="text" size="50" value="<?= HtmlSpecialChars($settings['kill_depth']) ?>"/><br />
	<small>How many levels deep does the story have to go before the option to end the story branch is available?</small></p><br />
	
	<p><input type="submit" value="Save Changes" /></p>
</form>

<?php
	include('footer.txt');
?>
    </section>