<!doctype html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, maximum-scale=1">

	<title>Homepage</title>
	<link rel="icon" href="testicon.png" type="image/png">
	<link rel="shortcut icon" href="testicon.ico" type="img/x-icon">


	<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="css/style.css" rel="stylesheet" type="text/css">
	<link href="css/font-awesome.css" rel="stylesheet" type="text/css">
	<link href="css/responsive.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" type="text/css">

	<script type="text/javascript" src="js/jquery.1.8.3.min.js"></script>
	<script type="text/javascript" src="js/jquery-scrolltofixed.js"></script>
	<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
	<script type="text/javascript" src="js/jquery.isotope.js"></script>

</head>

<body>

	<nav class="main-nav-outer" id="test">
		<!--main-nav-start-->
		<div class="container">
      <div class="small-logo-mobile"><a href=""><img src="img/testicon.png" alt=""></a></div>
			<ul class="main-nav">
				<li><a href="../../home.php">Home</a></li>
				<li class="small-logo"><a href=""><img src="img/testicon.png" alt=""></a></li>
                <li><a href="../../loginregister/">Login</a></li>
			</ul>
			<a class="res-nav_click" href="#"><i class="fa fa-bars"></i></a>
		</div>
	</nav>
    

	<section class="main-section client-part" id="service">
		<!--main-section-start-->
<?php
	include('config.php');
	include('db.php');


	include('header.txt');

	function insertRoutes($id, $data){
        global $db;
		$count = 0;
		$room = db_single(mysqli_query($db,"SELECT * FROM choose_rooms WHERE id=$id"));
		if ($room['end_here']){
			print $data."<td bgcolor=\"#ffcccc\"><a href=\"PWTroom.php?room=$id\">$id</a></td></tr>";
			$count++;
		}else{
			$data .= "<td bgcolor=\"#eeeeee\"><a href=\"PWTroom.php?room=$id\">$id</a></td>";
			if ($room['room_1']){
				$count += insertRoutes($room['room_1'],$data);
			}else{
				print $data."<td bgcolor=\"#cccccc\">Choice 1</td></tr>";
				$count++;
			}
			if ($room['room_2']){
				$count += insertRoutes($room['room_2'],$data);
			}else{
				print $data."<td bgcolor=\"#cccccc\">Choice 2</td></tr>";
				$count++;
			}
		}
		return $count;
        
	}

?>

There are quite a few routes through the game. Here they are (read left to right). Light gray is a normal room. Dark gray is an uncompleted story line. Red is an ending.<br>
<br>
<br>
<center>
<table cellpadding="30" cellspacing="20" border="5">
<caption>Each Possible Story Pathways</caption>
<?php
$count = insertRoutes(1,'<tr>'); ?>
</table>
</center>
<br>
There are currently <?php echo $count; ?> routes through the story.

<?php
	include('footer.txt');
?>
    </section>