CREATE TABLE choose_rooms (
 id int(11) NOT NULL auto_increment,
 email varchar(255) NOT NULL default '',
 blurb text NOT NULL,
 text_1 varchar(255) NOT NULL default '',
 room_1 int(11) NOT NULL default '0',
 text_2 varchar(255) NOT NULL default '',
 room_2 int(11) NOT NULL default '0',
 end_here tinyint(4) NOT NULL default '0',
 ip varchar(255) NOT NULL default '',
 PRIMARY KEY (id)
);

INSERT INTO choose_rooms VALUES (1, 'mrmephros@gmail.com', 'First Room', 'Choice 1', 0, 'Choice 2', 0, 0, '');

CREATE TABLE `choose_settings` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(128) default NULL,
  `root_url` varchar(128) default NULL,
  `copyright_text` varchar(64) default NULL,
  `copyright_year` int(11) default NULL,
  `copyright_url` varchar(128) default NULL,
  `main_page_text` text,
  `warn_box_blurb` text,
  `new_room_blurb` text,
  `kill_depth` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1

INSERT INTO `choose_settings` VALUES (1,'The Mighty Nein','','Michael McQ',2020,'mrmephros@gmail.com','You have stumbled upon my very own \"Choose your own adventure\" Experience.\r\n\r\nIt\'s a work in progress, partly because I don\'t have the time to write a whole story from start to finish, but mostly because you have the option of expanding it!\r\n. There is one story that is finished so use that as a demo of what can be done with the project.','This game is not suitable for children. Some story choices contain language and situations that some adults may find offensive or even possibly unsettling. This story is written by visitors to the site, and is largely unmoderated. Please do not use this in the classrooms before checking it. ','It\'s time you take to the stage and add to the adventure with your own possible choices.',5);

