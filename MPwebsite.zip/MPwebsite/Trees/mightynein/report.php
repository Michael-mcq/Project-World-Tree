<!doctype html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, maximum-scale=1">

	<title>Homepage</title>
	<link rel="icon" href="testicon.png" type="image/png">
	<link rel="shortcut icon" href="testicon.ico" type="img/x-icon">


	<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="css/style.css" rel="stylesheet" type="text/css">
	<link href="css/font-awesome.css" rel="stylesheet" type="text/css">
	<link href="css/responsive.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" type="text/css">

	<script type="text/javascript" src="js/jquery.1.8.3.min.js"></script>
	<script type="text/javascript" src="js/jquery-scrolltofixed.js"></script>
	<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
	<script type="text/javascript" src="js/jquery.isotope.js"></script>

</head>

<body>

	<nav class="main-nav-outer" id="test">
		<!--main-nav-start-->
		<div class="container">
      <div class="small-logo-mobile"><a href=""><img src="img/testicon.png" alt=""></a></div>
			<ul class="main-nav">
				<li><a href="../../home.php">Home</a></li>
				<li class="small-logo"><a href=""><img src="img/testicon.png" alt=""></a></li>
                <li><a href="../../loginregister/">Login</a></li>
			</ul>
			<a class="res-nav_click" href="#"><i class="fa fa-bars"></i></a>
		</div>
	</nav>
    	<section class="main-section client-part" id="service">

<?php
	include('config.php');
	include('db.php');
	include('header.txt');


	#
	# save changes?
	#

	if ($_POST['done']){

		if ($settings['enable_recaptcha'] == 1) {
		        require_once('recaptchalib.php');
		        $privatekey = $settings['recaptcha_private_key'];
		        $resp = recaptcha_check_answer ($privatekey,
                        $_SERVER["REMOTE_ADDR"],
                        $_POST["recaptcha_challenge_field"],
                        $_POST["recaptcha_response_field"]);
        		if (!$resp->is_valid) {
        	        echo "The reCAPTCHA wasn't entered correctly. Try again. (".$resp->error.")";
			include('footer.txt');
			exit;
       		 	}	
		}


		$id = intval($_POST['id']);

		$subject = "report for room $id";
		$message = "edit.php?id=$id\n\n".$_POST['message'];
		$headers = 'From: '.$config['email']. "\r\n" .
    		'Reply-To: webmaster@example.com' . "\r\n" .
    		'X-Mailer: PHP/' . phpversion();

		mail($config['email'], $subject, $message);


		echo "Thanks! The authorities have been alerted to your plight.";
		include('footer.txt');

		exit;
	}


	#
	# get info for display
	#
    
    if (isset($_GET['id'])) {
	$room_id = intval($_GET['id']); }
    else {
        $room_id = 1;
    }

	$room	= db_single(mysqli_query($db,"SELECT * FROM choose_rooms WHERE id=".$room_id));
	$parent	= db_single(mysqli_query($db,"SELECT * FROM choose_rooms WHERE room_1=".$room_id." OR room_2=".$room_id));

	if (!$room['id']){
		print "error: room ".$room_id." not found";
		include('footer.txt');
		exit;
	}


?>


	<h1>Report <a href="PWTroom.php?room=<?= $room['id']?>">Room <?= $room['id']?></a></h1>
	<br />

	Description:<br />
	<div class="boxy"><?= HtmlSpecialChars($room['blurb'])?></div>
	<br />

	Choice 1:<br />
	<div class="boxy"><?= HtmlSpecialChars($room['text_1'])?></div>
	<br />

	Choice 2:<br />
	<div class="boxy"><?= HtmlSpecialChars($room['text_2'])?></div>
	<br />

<form action="report.php" method="post">
<input type="hidden" name="id" value="<?= $room['id']?>" />
<input type="hidden" name="done" value="1" />

	<br /><p>Complaint:<br /><textarea name="message" cols="50" rows="10"></textarea></p>


	<p>
		<input type="submit" value="Send Report" />
	</p>
</form>


<?php
	include('footer.txt');
?>
            </section>
