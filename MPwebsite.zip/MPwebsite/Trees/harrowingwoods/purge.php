<!doctype html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, maximum-scale=1">

	<title>Homepage</title>
	<link rel="icon" href="testicon.png" type="image/png">
	<link rel="shortcut icon" href="testicon.ico" type="img/x-icon">


	<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="css/style.css" rel="stylesheet" type="text/css">
	<link href="css/font-awesome.css" rel="stylesheet" type="text/css">
	<link href="css/responsive.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" type="text/css">

	<script type="text/javascript" src="js/jquery.1.8.3.min.js"></script>
	<script type="text/javascript" src="js/jquery-scrolltofixed.js"></script>
	<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
	<script type="text/javascript" src="js/jquery.isotope.js"></script>

</head>

<body>

	<nav class="main-nav-outer" id="test">
		<!--main-nav-start-->
		<div class="container">
      <div class="small-logo-mobile"><a href=""><img src="img/testicon.png" alt=""></a></div>
			<ul class="main-nav">
				<li><a href="../../home.php">Home</a></li>
				<li class="small-logo"><a href=""><img src="img/testicon.png" alt=""></a></li>
                <li><a href="../../loginregister/">Login</a></li>
			</ul>
			<a class="res-nav_click" href="#"><i class="fa fa-bars"></i></a>
		</div>
	</nav>
    

	<section class="main-section alabaster" id="service">
		<!--main-section-start-->
<?php
	include('config.php');
	include('db.php');


	$result = mysqli_query($db,"SELECT id FROM choose_rooms WHERE end_here=0 AND blurb='' AND room_1=0 AND room_2=0");
    
    $ret = mysqli_fetch_array($result, MYSQLI_ASSOC);
    if ($ret) {
	foreach ($ret['rows'] as $row){
		$ok = delete_room($row['id']);
		echo $ok?'. ':'x '; flush();
	} }

	$result = mysqli_query($db,"SELECT id FROM choose_rooms WHERE end_here=0 AND text_1='' AND room_1=0 AND room_2=0");
    $ret = mysqli_fetch_array($result, MYSQLI_ASSOC);
    if ($ret) {
	foreach ($ret['rows'] as $row){
		$ok = delete_room($row['id']);
		echo $ok?'. ':'x '; flush();
	}
    }
	$result = mysqli_query($db,"SELECT id FROM choose_rooms WHERE end_here=0 AND text_2='' AND room_1=0 AND room_2=0");
    $ret = mysqli_fetch_array($result, MYSQLI_ASSOC);
    if ($ret) {
	foreach ($ret['rows'] as $row){
		$ok = delete_room($row['id']);
		echo $ok?'. ':'x '; flush();
	} }

	echo "<br />All done!";



	function delete_room($id){
        global $db;
		$room = db_single(mysqli_query($db,"SELECT * FROM choose_rooms WHERE id=".$id));
		$parent	= db_single(mysqli_query($db,"SELECT * FROM choose_rooms WHERE room_1=".$id." OR room_2=".$id));

		if ($room['room_1']) return 0;
		if ($room['room_2']) return 0;

		db_write("DELETE FROM choose_rooms WHERE id=".$id);

		if ($parent['id']){
			db_write("UPDATE choose_rooms SET room_1=0 WHERE id=".$parent['id']." AND room_1=".$id);
			db_write("UPDATE choose_rooms SET room_2=0 WHERE id=".$parent['id']." AND room_2=".$id);
		}

		return 1;
	}

?>
    </section>