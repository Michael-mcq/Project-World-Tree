<?php
$config['name'] = 'michael';
$config['password'] = 'root';
$config['email'] = 'mrmephros@gmail.com';
$config['db_user'] = 'root';
$config['db_pass'] = '';
$config['db_data'] = 'itfollows';
$config['db_host'] = 'localhost';
?>