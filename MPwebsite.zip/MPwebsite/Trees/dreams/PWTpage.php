<!doctype html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, maximum-scale=1">

	<title>Homepage</title>
	<link rel="icon" href="testicon.png" type="image/png">
	<link rel="shortcut icon" href="testicon.ico" type="img/x-icon">


	<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="css/style.css" rel="stylesheet" type="text/css">
	<link href="css/responsive.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" type="text/css">

	<script type="text/javascript" src="js/jquery.1.8.3.min.js"></script>
	<script type="text/javascript" src="js/jquery-scrolltofixed.js"></script>
	<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
	<script type="text/javascript" src="js/jquery.isotope.js"></script>

</head>

<body>

	<nav class="main-nav-outer" id="test">
		<!--main-nav-start-->
		<div class="container">
      <div class="small-logo-mobile"><a href=""><img src="img/testicon.png" alt=""></a></div>
			<ul class="main-nav">
				<li><a href="../../home.php">Home</a></li>
				<li class="small-logo"><a href=""><img src="img/testicon.png" alt=""></a></li>
                <li><a href="../../loginregister/">Login</a></li>
			</ul>
			<a class="res-nav_click" href="#"><i class="fa fa-bars"></i></a>
		</div>
	</nav>
    

	<section class="main-section client-part" id="service">
		<div  style="overflow-x:auto;">
         <?php
	include('config.php');
	include('db.php');
	 include('header.txt'); 

print nl2br(htmlentities(chop($settings['main_page_text'])));
?>

<br /><br />
So what are you waiting for? <a href="PWTroom.php" style="font-size: 130%;">Start playing</a>.
<br /><br />
<?php
	include('footer.txt');
?>
		</div>
	</section>



</body>

</html>
