<!doctype html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, maximum-scale=1">

	<title>Homepage</title>
	<link rel="icon" href="testicon.png" type="image/png">
	<link rel="shortcut icon" href="testicon.ico" type="img/x-icon">

	<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,800italic,700italic,600italic,400italic,300italic,800,700,600' rel='stylesheet' type='text/css'>

	<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="css/style.css" rel="stylesheet" type="text/css">
	<link href="css/font-awesome.css" rel="stylesheet" type="text/css">
	<link href="css/responsive.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" type="text/css">

	<script type="text/javascript" src="js/jquery.1.8.3.min.js"></script>
	<script type="text/javascript" src="js/jquery-scrolltofixed.js"></script>
	<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
	<script type="text/javascript" src="js/jquery.isotope.js"></script>
	

</head>

<body>
	<header class="header" id="header">
		<!--header-start-->
		<div class="container">
			<figure class="logo animated fadeInDown delay-07s">
				<a href="#"><img src="img/testicon.png" alt=""></a>
			</figure>
			<h1 class="animated fadeInDown delay-07s">Welcome To Project: World Tree</h1>
			<ul class="we-create animated fadeInUp delay-1s">
				<li>We are a here to bring your adventures to life.</li>
			</ul>
			<a class="link animated fadeInUp delay-1s servicelink" href="#Experiences">Get Started</a>
		</div>
	</header>
	<!--header-end-->

	<nav class="main-nav-outer" id="test">
		<!--main-nav-start-->
		<div class="container">
      <div class="small-logo-mobile"><a href="#header"><img src="img/testicon.png" alt=""></a></div>
			<ul class="main-nav">
				<li><a href="#header">Home</a></li>
				<li><a href="#function">Function</a></li>
				<li><a href="#Experiences">Experiences</a></li>
				<li class="small-logo"><a href="#header"><img src="img/testicon.png" alt=""></a></li>
				<li><a href="#popular">Popular</a></li>
				<li><a href="#contact">Contact</a></li>
                <li><a href="loginregister/">Login</a></li>
			</ul>
			<a class="res-nav_click" href="#"><i class="fa fa-bars"></i></a>
		</div>
	</nav>
	<!--main-nav-end-->



	<section class="main-section alabaster" id="function">
		<!--main-section-start-->
		<div class="container">
			<h2>Function</h2>
			<h6>Below is information about the website and its main function.</h6>
			<div class="row">
				<div class="col-lg-4 col-sm-6 wow fadeInLeft delay-05s">
					<div class="service-list">
						<div class="service-list-col1">
							<i class="fa fa-paw"></i>
						</div>
						<div class="service-list-col2">
							<h3>Main Aim</h3>
							<p>The main aim of the website is to allow the users to play throught created stories mad by others or even create their own.</p>
						</div>
					</div>
					<div class="service-list">
						<div class="service-list-col1">
							<i class="fa fa-gear"></i>
						</div>
						<div class="service-list-col2">
							<h3>Design</h3>
							<p>The current design is focused on function since this project is so massive it will always continueously grow looks wise and functionally.</p>
						</div>
					</div>
					<div class="service-list">
						<div class="service-list-col1">
							<i class="fa fa-apple"></i>
						</div>
						<div class="service-list-col2">
							<h3>Stories</h3>
							<p>All stories that are added to the site are still the intellectual property of its creator but we ask that you respect others work &amp; that some may be similar.</p>
						</div>
					</div>
					<div class="service-list">
						<div class="service-list-col1">
							<i class="fa fa-medkit"></i>
						</div>
						<div class="service-list-col2">
							<h3>Uses</h3>
							<p>This website allows creators to put their content or stories into our Experience trees so that you can make your own Choose Your own adventure experience.Currently this consists of each choice that is in the story leads to another creating a new experience each time a story is played.</p>
						</div>
					</div>
				</div>
				<figure class="col-lg-8 col-sm-6  text-right wow fadeInUp delay-02s">
					<img src="img/imac.png" alt="">
				</figure>

			</div>
		</div>
	</section>
	<!--main-section-end-->

	<section class="main-section paddind" id="Experiences">
		<!--main-section-start-->
		<div class="container">
			<h2>Experiences</h2>
			<h6>Freshly created Experiences that will keep you wanting more.</h6>
			<div class="portfolioFilter">
				<ul class="Portfolio-nav wow fadeIn delay-02s">
					<li><a href="#" data-filter="*" class="current">All</a></li>
					<li><a href="#" data-filter=".fantasy">Fantasy</a></li>
					<li><a href="#" data-filter=".survival">Survival</a></li>
					<li><a href="#" data-filter=".adventure">Adventure</a></li>
					<li><a href="#" data-filter=".horror">Horror</a></li>
				</ul>
			</div>

		</div>
		<div class="portfolioContainer wow fadeInUp delay-04s">
			<div class=" Portfolio-box adventure">
				<a href="Trees/mightynein/PWTpage.php"><img src="img/Mighty-Nein.png" alt=""></a>
				<h3>The Mighty Nein</h3>
				<p>Adventure</p>
			</div>
			<div class="Portfolio-box fantasy">
				<a href="Trees/dreams/PWTpage.php"><img src="img/dreams.jpg" alt=""></a>
				<h3>Dream</h3>
				<p>fantasy</p>
			</div>
			<div class=" Portfolio-box fantasy">
				<a href="Trees/harrowingwoods/PWTpage.php"><img src="img/harrowing-woods.jpg" alt=""></a>
				<h3>Harrowing Woods</h3>
				<p>Fantasy</p>
			</div>
			<div class=" Portfolio-box survival">
				<a href="Trees/zombieattack/PWTpage.php"><img src="img/zombie.jpg" alt=""></a>
				<h3>Zombie Attack</h3>
				<p>Survival</p>
			</div>
			<div class=" Portfolio-box fantasy">
				<a href="Trees/PWTDemo/PWTpage.php"><img src="img/swordlegend-ori2.jpg" alt=""></a>
				<h3>Sword Legend</h3>
				<p>Fantasy</p>
			</div>
			<div class=" Portfolio-box horror">
				<a href="Trees/itfollows/PWTpage.php"><img src="img/it-follows.jpg" alt=""></a>
				<h3>It Follows</h3>
				<p>Horror</p>
			</div>
		</div>
	</section>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    
    <br>
    <br>
    <br>
    <br>
    <br>
    <br><br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    
	<!--main-section-end-->
<section class="main-section" id="service">
		<!--main-section-start-->
		<div class="container">
			
		</div>
	</section>

	<section class="main-section client-part" id="popular">
		<!--main-section client-part-start-->
		<div class="container">
			<b class="quote-right wow fadeInDown delay-03"><i class="fa fa-quote-right"></i></b>
			<div class="row">
				<div class="col-lg-12">
					<p class="client-part-haead wow fadeInDown delay-05">Popular Fantasy Adventure this week.</p>
				</div>
			</div>
			<ul class="client wow fadeIn delay-05s">
				<li><a href="Trees/dreams/PWTpage.php">
            	<img src="img/dreams.jpg" alt="">
                <h3>Dream</h3>
                <span>The story of a young girl with the recent passing of her mother deals with the dreams she has been having.</span>
            </a></li>
			</ul>
		</div>
	</section>
	<!--main-section client-part-end-->

	<!--business-talking-end-->
	<div class="container">
		<section class="main-section contact" id="contact">

			<div class="row">
				<div class="col-lg-6 col-sm-7 wow fadeInLeft">
					<div class="contact-info-box address clearfix">
						<h3><i class=" icon-map-marker"></i>Address:</h3>
						<span>Belfast</span>
					</div>
					<div class="contact-info-box phone clearfix">
						<h3><i class="fa fa-phone"></i>Phone:</h3>
						<span>028</span>
					</div>
					<div class="contact-info-box email clearfix">
						<h3><i class="fa fa-pencil"></i>email:</h3>
						<span>@Gmail.com</span>
					</div>
					<ul class="social-link">
						<li class="twitter"><a target="_blank" rel="noopener noreferrer" href="https://twitter.com/explore"><i class="fa fa-twitter"></i></a></li>
						<li class="facebook"><a target="_blank" rel="noopener noreferrer" href="https://en-gb.facebook.com/"><i class="fa fa-facebook"></i></a></li>
						<li class="gplus"><a target="_blank" rel="noopener noreferrer" href="https://www.google.co.uk/"><i class="fa fa-google-plus"></i></a></li>
					</ul>
				</div>
				<div class="col-lg-6 col-sm-5 wow fadeInUp delay-05s">
					<div class="form">
							<?php
if(!empty($_POST["send"])) {
	$name = $_POST["userName"];
	$email = $_POST["userEmail"];
	$subject = $_POST["subject"];
	$content = $_POST["content"];

	$conn = mysqli_connect("localhost", "root", "", "testcontact") or die("Connection Error: " . mysqli_error($conn));
	mysqli_query($conn, "INSERT INTO tblcontact (user_name, user_email,subject,content) VALUES ('" . $name. "', '" . $email. "','" . $subject. "','" . $content. "')");
	$insert_id = mysqli_insert_id($conn);
	//if(!empty($insert_id)) {
	   $message = "Your contact information is saved successfully.";
	   $type = "success";
	//}
}
require_once "php-contact-form/contact-view.php";
?>
	<div class="container">
		
	</div>
						
					</div>
				</div>
			</div>
		</section>
	</div>
	<footer class="footer">
		<div class="container">
			<div class="footer-logo"><a href="#header"><img src="img/testicon.png" alt=""></a></div>
			<div class="credits">
			</div>
		</div>
	</footer>


	<script type="text/javascript">
		$(document).ready(function(e) {

			$('#test').scrollToFixed();
			$('.res-nav_click').click(function() {
				$('.main-nav').slideToggle();
				return false

			});
		});
	</script>

	

	<script type="text/javascript">
		$(window).load(function() {

			$('.main-nav li a, .servicelink').bind('click', function(event) {
				var $anchor = $(this);

				$('html, body').stop().animate({
					scrollTop: $($anchor.attr('href')).offset().top - 102
				}, 1500, 'easeInOutExpo');
				/*
				if you don't want to use the easing effects:
				$('html, body').stop().animate({
					scrollTop: $($anchor.attr('href')).offset().top
				}, 1000);
				*/
				if ($(window).width() < 768) {
					$('.main-nav').hide();
				}
				event.preventDefault();
			});
		})
	</script>

	<script type="text/javascript">
		$(window).load(function() {


			var $container = $('.portfolioContainer'),
				$body = $('body'),
				colW = 375,
				columns = null;


			$container.isotope({
				// disable window resizing
				resizable: true,
				masonry: {
					columnWidth: colW
				}
			});

			$(window).smartresize(function() {
				// check if columns has changed
				var currentColumns = Math.floor(($body.width() - 30) / colW);
				if (currentColumns !== columns) {
					// set new column count
					columns = currentColumns;
					// apply width to container manually, then trigger relayout
					$container.width(columns * colW)
						.isotope('reLayout');
				}

			}).smartresize(); // trigger resize to set container width
			$('.portfolioFilter a').click(function() {
				$('.portfolioFilter .current').removeClass('current');
				$(this).addClass('current');

				var selector = $(this).attr('data-filter');
				$container.isotope({

					filter: selector,
				});
				return false;
			});

		});
	</script>

</body>

</html>
