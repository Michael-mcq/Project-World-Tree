<?php
include 'upload.php';
?>
<!DOCTYPE html>
<html lang="en-US">
<head> 
    <title>Upload Image</title>
    <meta charset="utf-8">
</head>
    <body>

         <?php if(!empty($statusMsg)){ ?>
         <?php echo $statusMsg; ?>
         <?php } ?>
    <form action="upload.php" method="post" enctype="multipart/form-data">
    Select Image File to Upload:
    <input type="file" name="file">
    <input type="submit" name="submit" value="Upload">
</form>
         
      
    <?php
    include 'dbConfig.php';
    
    $query = $db->query("SELECT * FROM images ORDER BY uploaded_on DESC");
    
    if($query->num_rows > 0){
        while($row = $query->fetch_assoc()){
            $imageURL = 'uploads/'.$rows["file_name"];
            ?>
    <img src="<?php echo $imageURL; ?>" alt="" />
    <?php
        }
    }else{
        ?>
    <p>NO image(s) found...</p>
    <?php
    }
    ?>
 
        
    </body>
</html>